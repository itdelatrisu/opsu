package org.newdawn.slick.command;

/**
 * Marker class for abstract input controls
 * 
 * @author joverton
 */
public interface Control {
}
