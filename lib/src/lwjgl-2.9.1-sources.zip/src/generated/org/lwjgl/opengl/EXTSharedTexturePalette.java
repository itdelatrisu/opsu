/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTSharedTexturePalette {

	public static final int GL_SHARED_TEXTURE_PALETTE_EXT = 0x81FB;

	private EXTSharedTexturePalette() {}
}
