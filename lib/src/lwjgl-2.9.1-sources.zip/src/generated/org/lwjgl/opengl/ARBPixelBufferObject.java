/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class ARBPixelBufferObject extends ARBBufferObject {

	/**
	 *  Accepted by the &lt;target&gt; parameters of BindBuffer, BufferData,
	 *  BufferSubData, MapBuffer, UnmapBuffer, GetBufferSubData,
	 *  GetBufferParameteriv, and GetBufferPointerv:
	 */
	public static final int GL_PIXEL_PACK_BUFFER_ARB = 0x88EB,
		GL_PIXEL_UNPACK_BUFFER_ARB = 0x88EC;

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_PIXEL_PACK_BUFFER_BINDING_ARB = 0x88ED,
		GL_PIXEL_UNPACK_BUFFER_BINDING_ARB = 0x88EF;

	private ARBPixelBufferObject() {}
}
