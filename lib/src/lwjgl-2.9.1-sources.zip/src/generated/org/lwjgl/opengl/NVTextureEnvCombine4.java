/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVTextureEnvCombine4 {

	public static final int GL_COMBINE4_NV = 0x8503,
		GL_SOURCE3_RGB_NV = 0x8583,
		GL_SOURCE3_ALPHA_NV = 0x858B,
		GL_OPERAND3_RGB_NV = 0x8593,
		GL_OPERAND3_ALPHA_NV = 0x859B;

	private NVTextureEnvCombine4() {}
}
