/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class NVGpuProgram5 {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  GetFloatv, and GetDoublev:
	 */
	public static final int GL_MAX_GEOMETRY_PROGRAM_INVOCATIONS_NV = 0x8E5A,
		GL_MIN_FRAGMENT_INTERPOLATION_OFFSET_NV = 0x8E5B,
		GL_MAX_FRAGMENT_INTERPOLATION_OFFSET_NV = 0x8E5C,
		GL_FRAGMENT_PROGRAM_INTERPOLATION_OFFSET_BITS_NV = 0x8E5D;

	private NVGpuProgram5() {}
}
