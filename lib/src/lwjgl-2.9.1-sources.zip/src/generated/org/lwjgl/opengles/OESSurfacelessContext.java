/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESSurfacelessContext {

	/**
	 * Returned by glCheckFramebufferStatusOES and glCheckFramebufferStatus: 
	 */
	public static final int GL_FRAMEBUFFER_UNDEFINED_OES = 0x8219;

	private OESSurfacelessContext() {}
}
