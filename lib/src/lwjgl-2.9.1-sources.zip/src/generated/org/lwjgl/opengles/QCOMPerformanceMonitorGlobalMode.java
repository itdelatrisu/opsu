/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class QCOMPerformanceMonitorGlobalMode {

	/**
	 *  Accepted by the &lt;cap&gt; parameter of Enable and Disable, and
	 *  IsEnabled, and by the &lt;pname&gt; parameter of GetBooleanv, GetIntegerv,
	 *  and GetFloatv:
	 */
	public static final int GL_PERFMON_GLOBAL_MODE_QCOM = 0x8FA0;

	private QCOMPerformanceMonitorGlobalMode() {}
}
