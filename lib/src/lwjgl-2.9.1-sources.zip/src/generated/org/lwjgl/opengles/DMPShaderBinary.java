/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class DMPShaderBinary {

	/**
	 * Accepted by the &lt;binaryformat&gt; parameter of ShaderBinary: 
	 */
	public static final int GL_SHADER_BINARY_DMP = 0x9250;

	private DMPShaderBinary() {}
}
