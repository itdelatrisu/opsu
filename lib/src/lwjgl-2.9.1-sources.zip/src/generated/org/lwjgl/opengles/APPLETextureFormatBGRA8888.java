/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class APPLETextureFormatBGRA8888 {

	/**
	 * Accepted by the &lt;format&gt; parameters of TexImage2D and TexSubImage2D: 
	 */
	public static final int GL_BGRA_EXT = 0x80E1;

	private APPLETextureFormatBGRA8888() {}
}
