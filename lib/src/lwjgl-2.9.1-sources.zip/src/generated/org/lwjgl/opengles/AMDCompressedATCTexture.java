/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class AMDCompressedATCTexture {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of CompressedTexImage2D and
	 *  CompressedTexImage3DOES.
	 */
	public static final int GL_ATC_RGB_AMD = 0x8C92,
		GL_ATC_RGBA_EXPLICIT_ALPHA_AMD = 0x8C93,
		GL_ATC_RGBA_INTERPOLATED_ALPHA_AMD = 0x87EE;

	private AMDCompressedATCTexture() {}
}
